from .stt import WhisperPlugin
from .stt_fast import FasterWhisperPlugin
