# llm-agents-plugins-whisper

OpenAI Whisper plugin for the `llm-agents` framework.

## Installation
```bash
pip install llm-agents-plugins-whisper
```

## Usage
```python
from plugins.whisper import WhisperPlugin
from core.events import EventManager

plugin = WhisperPlugin(model_size="base", event_manager=EventManager())
plugin.load()
transcript = await plugin.transcribe(audio_bytes)
```
