# faster_whisper_plugin.py
from pydantic import Field
from core.plugins.asr import AsrBase, AsrConfigModel, register_plugin
try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None
try:
    import numpy as np
except ImportError:
    pass
from typing import Union, Literal, Dict, Any
import base64
try:
    import librosa
except ImportError:
    librosa = None

class FasterWhisperConfigModel(AsrConfigModel):
    model_size: str = Field("base", description="Faster whisper model size (e.g.: tiny, base, small, medium, large-v2)")

@register_plugin("faster_whisper")
class FasterWhisperPlugin(AsrBase):

    CONFIG_MODEL = FasterWhisperConfigModel
    """
    Plugin nhận dạng giọng nói sử dụng thư viện faster-whisper.
    Thư viện này cung cấp tốc độ nhanh hơn và sử dụng bộ nhớ hiệu quả hơn
    so với thư viện whisper gốc của OpenAI.
    """
    def __init__(self, model_size: str = "base", **kwargs):
        """
        Khởi tạo plugin.
        
        Args:
            model_size (str): Kích thước của model (ví dụ: "tiny", "base", "small", "medium", "large-v2").
            compute_type (str, optional): Kiểu tính toán (ví dụ: "float16", "int8_float16", "int8").
                                          Nếu không được cung cấp, sẽ tự động chọn dựa trên thiết bị.
                                          "float16" cho GPU (cuda) và "int8" cho CPU.
            **kwargs: Các tham số khác cho lớp cơ sở.
        """
        super().__init__(**kwargs)
        self.model_size = model_size
        
    def load(self):
        """
        Tải model faster-whisper vào bộ nhớ.
        Sử dụng các tham số đã được định nghĩa trong __init__.
        """
        self.model = WhisperModel(
            self.model_size, 
            device=self.device, 
            compute_type="cpu"
        )
        print("Model loaded successfully.")
        return self
    
    def predict(self, audio: Union[str, np.ndarray, bytes]) -> str:
        """
        Thực hiện nhận dạng giọng nói trên dữ liệu âm thanh đầu vào.

        Args:
            audio (Union[str, np.ndarray, bytes]): Dữ liệu âm thanh. 
                                                   Có thể là đường dẫn tệp, numpy array, 
                                                   hoặc chuỗi bytes đã được mã hóa base64.

        Returns:
            str: Văn bản được nhận dạng từ âm thanh.
        """
        if self.model is None:
            self.load()
        
        audio_data = None
        # Xử lý các định dạng đầu vào khác nhau
        if isinstance(audio, str):
            # Kiểm tra xem chuỗi có phải là base64 không
            try:
                # Một cách đơn giản để kiểm tra base64, có thể cần cải thiện
                if len(audio) % 4 == 0 and audio.endswith('='):
                    decoded_bytes = base64.b64decode(audio)
                    audio_data = np.frombuffer(decoded_bytes, dtype=np.int16).astype(np.float32) / 32768.0
            except (ValueError, TypeError):
                # Nếu không phải base64, coi đó là đường dẫn tệp
                audio_data = self.preprocess(audio)
            
            if audio_data is None: # Nếu vẫn là None thì coi là đường dẫn file
                audio_data = self.preprocess(audio)

        elif isinstance(audio, bytes):
            # Chuyển đổi từ bytes thô
            audio_data = np.frombuffer(audio, dtype=np.int16).astype(np.float32) / 32768.0
        elif isinstance(audio, np.ndarray):
             # Đã là numpy array, chỉ cần đảm bảo đúng định dạng
            if audio.dtype != np.float32:
                audio_data = audio.astype(np.float32) / 32768.0 if audio.dtype == np.int16 else audio.astype(np.float32)
            else:
                audio_data = audio
        else:
            raise TypeError("Unsupported audio type. Must be str (path or base64), bytes, or numpy.ndarray.")

        # Thực hiện nhận dạng
        segments, info = self.model.transcribe(
            audio_data,
            language=self.language,
        )
        
        # Ghép các đoạn văn bản lại với nhau
        result_text = "".join(segment.text for segment in segments)
        
        return result_text.strip()