import json
import os, sys, json
from typing import Any, Dict
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from core.plugin_wrapper.server import PluginServer
from pydantic import BaseModel, Field

class GenericInput(BaseModel):
    params: Dict[str, Any] = Field(default_factory=dict, description="Generic parameters for the plugin")

def execute_generic(params: Dict[str, Any]) -> dict:
    plugin_name = "whisper"
    plugin_type = "asr"
    
    # Try to import the package to trigger registry
    try:
        import importlib
        importlib.import_module(f"plugins.whisper")
    except Exception as e:
        pass
        
    try:
        if plugin_type == "llm":
            from core.plugins.llm import LLM_PLUGIN_REGISTRY
            if plugin_name in LLM_PLUGIN_REGISTRY:
                plugin = LLM_PLUGIN_REGISTRY[plugin_name](**params)
                prompt = params.get("prompt", params.get("text", "Hello"))
                return {"text": plugin.generate(prompt)}
            
        elif plugin_type == "asr":
            import stt
            file_data = params.get("file") or params.get("input_file") or params.get("audio_data") or params.get("image") or params.get("audio") or params.get("input") or params.get("url") or params.get("file_path")
            if file_data is None and len(params) > 0:
                for v in params.values():
                    if isinstance(v, str) and (v.startswith("data:") or len(v) > 200 or os.path.exists(v)):
                        file_data = v
                        break
                if file_data is None:
                    file_data = list(params.values())[0]
            
            # Auto-detect audio file in current directory and workspace if missing
            if not file_data:
                import glob
                audio_files = glob.glob("*.mp3") + glob.glob("*.wav") + glob.glob("*.m4a") + \
                              glob.glob("/workspace/*.mp3") + glob.glob("/workspace/*.wav") + glob.glob("/workspace/*.m4a")
                if audio_files:
                    file_data = audio_files[0]
                    
            if file_data and not os.path.exists(file_data) and not str(file_data).startswith("data:"):
                # Try prefixing with /workspace/ if it doesn't exist
                if os.path.exists(os.path.join("/workspace", file_data)):
                    file_data = os.path.join("/workspace", file_data)
                    
            if file_data:
                return {"text": stt.predict(file_data)}
            return {"error": "No file provided"}
                
        elif plugin_type == "tts":
            from core.plugins.tts import TTS_PLUGIN_REGISTRY
            if plugin_name in TTS_PLUGIN_REGISTRY:
                plugin = TTS_PLUGIN_REGISTRY[plugin_name](**params)
                text = params.get("text", "Hello")
                # synthesize returns either a file path or bytes
                import asyncio
                # some are async, some are sync. This is risky without knowing the exact signature.
                # But we will do a best-effort approach.
                if asyncio.iscoroutinefunction(plugin.synthesize):
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                    res = loop.run_until_complete(plugin.synthesize(text))
                else:
                    res = plugin.synthesize(text)
                
                # If it's a file path
                if isinstance(res, str) and os.path.exists(res):
                    import base64
                    with open(res, "rb") as f:
                        b64_audio = base64.b64encode(f.read()).decode('utf-8')
                    return {"status": "success", "output_files": [{"name": "audio.mp3", "content": b64_audio, "encoding": "base64"}]}
                elif isinstance(res, bytes):
                    import base64
                    b64_audio = base64.b64encode(res).decode('utf-8')
                    return {"status": "success", "output_files": [{"name": "audio.mp3", "content": b64_audio, "encoding": "base64"}]}
                return {"result": str(res)}
                
        elif plugin_type in ["video", "vision", "media"]:
            from core.plugins.video import VIDEO_PLUGIN_REGISTRY
            from core.plugins.image import IMAGE_PLUGIN_REGISTRY
            if plugin_name in VIDEO_PLUGIN_REGISTRY:
                plugin = VIDEO_PLUGIN_REGISTRY[plugin_name](**params)
                return {"result": "Video generation triggered", "data": str(plugin)}
            if plugin_name in IMAGE_PLUGIN_REGISTRY:
                plugin = IMAGE_PLUGIN_REGISTRY[plugin_name](**params)
                return {"result": "Image generation triggered", "data": str(plugin)}
                
    except Exception as e:
        return {"error": f"Failed to execute real plugin logic: {str(e)}"}
        
    return {"error": f"Real implementation for whisper not found in registry."}

if __name__ == "__main__":
    server = PluginServer(name="whisper Microservice", description="Real implementation wrapper", port_rest=8301)
    server.register_tool(name="execute", func=execute_generic, schema=GenericInput, description="Execute Real Logic")
    server.start()
