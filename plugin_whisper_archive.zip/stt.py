# stt.py (Standalone Whisper Plugin)
import os
import json
import base64
import tempfile
import urllib.request
import urllib.error
import urllib.parse
import subprocess

def run_api_inference(audio_bytes, api_key=None, base_url=None):
    """Fallback to API when running on plugin-server without torch"""
    api_key = api_key or os.getenv("SYNORA_API_KEY", "sk_synora_mtCK5O2gmUJS0vEq-iJL_6q_3yZK5MXNQdBxClIm0ec")
    base_url = base_url or os.getenv("SYNORA_BASE_URL", "https://synora-os-beta.vercel.app/api/v1")
    
    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name

    try:
        cmd = [
            "curl", "-s", f"{base_url}/audio/transcriptions",
            "-H", f"Authorization: Bearer {api_key}",
            "-F", f"file=@{tmp_path}",
            "-F", "model=whisper-1"
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            return f"Error calling API: {result.stderr.strip()}"
            
        try:
            resp_json = json.loads(result.stdout)
            if "error" in resp_json:
                return f"API Error: {resp_json['error']}"
            return resp_json.get("text", result.stdout.strip())
        except json.JSONDecodeError:
            out = result.stdout.strip()
            if out.startswith("<") or "html" in out.lower():
                return f"Error: API returned an HTML page (likely 404 Not Found). Please verify the BASE_URL ({base_url}) is correct and the endpoint exists."
            return f"Error: API returned invalid JSON: {out[:200]}..."
            
    except Exception as e:
        return f"Error executing curl: {str(e)}"
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

def run_local_inference(audio_bytes, model_size="base"):
    """Run real local PyTorch inference (Used in Sandbox/SSH)"""
    try:
        import torch
        import whisper
        import numpy as np
    except ImportError:
        # Fallback to API if dependencies are missing even in Sandbox
        return run_api_inference(audio_bytes)

    import tempfile
    import os
    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name
        
    try:
        audio_data = whisper.load_audio(tmp_path)
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = whisper.load_model(model_size, device=device)
    
    result = model.transcribe(audio_data, fp16=(device=="cuda"))
    return result["text"].strip()

def predict(audio_input):
    """Main entrypoint for plugin-server wrapper"""
    audio_bytes = None
    if isinstance(audio_input, str):
        if audio_input.startswith('data:') or len(audio_input) > 255:
            audio_bytes = base64.b64decode(audio_input.split(',')[-1] if ',' in audio_input else audio_input)
        elif os.path.exists(audio_input):
            with open(audio_input, "rb") as f:
                audio_bytes = f.read()
        elif os.path.exists(os.path.join("/workspace", audio_input)):
            with open(os.path.join("/workspace", audio_input), "rb") as f:
                audio_bytes = f.read()
    elif isinstance(audio_input, bytes):
        audio_bytes = audio_input

    if not audio_bytes:
        return "Error: Invalid audio input"

    # Try local inference first (if torch is installed), else fallback to API
    try:
        import torch
        return run_local_inference(audio_bytes)
    except ImportError:
        return run_api_inference(audio_bytes)

class WhisperPlugin:
    def __init__(self, **kwargs):
        pass
    def predict(self, audio_input):
        return predict(audio_input)

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python stt.py <path_to_audio_file> [callback_url]")
        sys.exit(1)
        
    audio_path = sys.argv[1]
    callback_url = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Read audio
    with open(audio_path, "rb") as f:
        audio_bytes = f.read()
        
    # Run inference
    result_text = predict(audio_bytes)
    
    # Webhook callback or stdout

    # --- BINARY FILE HANDLING PATCH ---
    if "numpy.ndarray" in str(type(result_text)):
        try:
            import soundfile as sf
            import os
            sr = getattr(plugin, "sample_rate", 24000)
            output_path = os.path.abspath("output.wav")
            sf.write(output_path, result_text, sr)
            import subprocess, json

            _direct_url = None

            try:

                _upload_res = subprocess.run(["curl", "-s", "-F", f"file=@{output_path}", "https://tmpfiles.org/api/v1/upload"], capture_output=True, text=True, timeout=15)

                _res_json = json.loads(_upload_res.stdout)

                if "data" in _res_json and "url" in _res_json["data"]:

                    _url = _res_json["data"]["url"]

                    _direct_url = _url.replace("tmpfiles.org/", "tmpfiles.org/dl/")

            except Exception: pass

            

            if not _direct_url:

                try:

                    _upload_res = subprocess.run(["curl", "-s", "-F", f"file=@{output_path}", "https://0x0.st"], capture_output=True, text=True, timeout=15)

                    if _upload_res.stdout and _upload_res.stdout.startswith("http"):

                        _direct_url = _upload_res.stdout.strip()

                except Exception: pass

            

            if not _direct_url:

                try:

                    _upload_res = subprocess.run(["curl", "-s", "-F", "reqtype=fileupload", "-F", "time=24h", "-F", f"fileToUpload=@{output_path}", "https://litterbox.catbox.moe/user/api.php"], capture_output=True, text=True, timeout=15)

                    if _upload_res.stdout and _upload_res.stdout.startswith("http"):

                        _direct_url = _upload_res.stdout.strip()

                except Exception: pass

            

            if _direct_url:

                result_text = f"File generated successfully! Preview/Download link: {_direct_url}"

            else:

                result_text = f"Audio saved to {output_path}. Use export_and_download_file(sandbox_path='{output_path}') to send it to the user."
        except Exception as e:
            result_text = f"Error saving numpy array to audio: {e}"
    elif isinstance(result_text, bytes):
        try:
            import os
            output_path = os.path.abspath("output.bin")
            with open(output_path, "wb") as f:
                f.write(result_text)
            import subprocess, json

            _direct_url = None

            try:

                _upload_res = subprocess.run(["curl", "-s", "-F", f"file=@{output_path}", "https://tmpfiles.org/api/v1/upload"], capture_output=True, text=True, timeout=15)

                _res_json = json.loads(_upload_res.stdout)

                if "data" in _res_json and "url" in _res_json["data"]:

                    _url = _res_json["data"]["url"]

                    _direct_url = _url.replace("tmpfiles.org/", "tmpfiles.org/dl/")

            except Exception: pass

            

            if not _direct_url:

                try:

                    _upload_res = subprocess.run(["curl", "-s", "-F", f"file=@{output_path}", "https://0x0.st"], capture_output=True, text=True, timeout=15)

                    if _upload_res.stdout and _upload_res.stdout.startswith("http"):

                        _direct_url = _upload_res.stdout.strip()

                except Exception: pass

            

            if not _direct_url:

                try:

                    _upload_res = subprocess.run(["curl", "-s", "-F", "reqtype=fileupload", "-F", "time=24h", "-F", f"fileToUpload=@{output_path}", "https://litterbox.catbox.moe/user/api.php"], capture_output=True, text=True, timeout=15)

                    if _upload_res.stdout and _upload_res.stdout.startswith("http"):

                        _direct_url = _upload_res.stdout.strip()

                except Exception: pass

            

            if _direct_url:

                result_text = f"File generated successfully! Preview/Download link: {_direct_url}"

            else:

                result_text = f"Binary file saved to {output_path}. Use export_and_download_file(sandbox_path='{output_path}') to send it to the user."
        except Exception as e:
            result_text = f"Error saving bytes: {e}"
    # ----------------------------------
    
    if callback_url:

        req_data = json.dumps({"status": "success", "result": result_text}).encode('utf-8')
        req = urllib.request.Request(callback_url, data=req_data, headers={'Content-Type': 'application/json'})
        try:
            urllib.request.urlopen(req)
            print(f"[Webhook] Sent result to {callback_url}")
        except Exception as e:
            print(f"[Webhook] Error sending callback: {e}")
            print(f"STT_RESULT: {result_text}")
    else:
        print(f"STT_RESULT: {result_text}")